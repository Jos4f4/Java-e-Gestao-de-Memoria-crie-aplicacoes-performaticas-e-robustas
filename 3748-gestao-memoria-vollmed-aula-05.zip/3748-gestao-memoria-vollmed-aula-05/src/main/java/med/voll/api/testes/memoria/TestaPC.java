package med.voll.api.testes.memoria;

public class TestaPC {
    public static void main(String[] args) {
        System.out.println(soma(3, 5));
        System.out.println(soma(4, 9));
    }

    public static int soma(int valor1, int valor2){
        return valor1 + valor2;
    }
}
